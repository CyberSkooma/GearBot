import tempfile
import unittest
from pathlib import Path
from gear import FIELDS, Store, render

class GearTests(unittest.TestCase):
    def test_persistence_isolation_replace_and_delete(self):
        with tempfile.TemporaryDirectory() as folder:
            path = str(Path(folder) / 'gear.sqlite3')
            store = Store(path)
            store.save(1, 10, {'Backpack': 'Crown 2 60'})
            self.assertEqual(Store(path).get(1, 10)['Backpack'], 'Crown 2 60')
            self.assertIsNone(store.get(2, 10))
            self.assertIsNone(store.get(1, 11))
            store.save(1, 10, {'Backpack': 'New pack'})
            self.assertEqual(store.get(1, 10), {'Backpack': 'New pack'})
            self.assertTrue(store.delete(1, 10))
            self.assertIsNone(Store(path).get(1, 10))

    def test_output_fits_discord_and_cannot_escape_code_box(self):
        values = {field: 'x' * (400 if i == 7 else 140) for i, field in enumerate(FIELDS)}
        self.assertLess(len(render(values)) + 200, 2000)
        output = render({'Backpack': 'evil```\n@everyone'})
        self.assertEqual(output.count('```'), 2)
        self.assertIn('Total Base Weight: Unweighed', output)
        self.assertIn('\n\nExtra or Misc Items:', output)

if __name__ == '__main__':
    unittest.main()
