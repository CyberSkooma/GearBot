import logging
import os
from pathlib import Path

import discord
from discord import app_commands
from dotenv import load_dotenv
from gear import FIELDS, Store, clean, render

load_dotenv(Path(__file__).with_name('.env'))
log = logging.getLogger('backpacking')
store = Store(os.getenv('GEAR_DATABASE', str(Path(__file__).with_name('gear.sqlite3'))))

class Client(discord.Client):
    def __init__(self):
        super().__init__(intents=discord.Intents.none(), allowed_mentions=discord.AllowedMentions.none())
        self.tree = app_commands.CommandTree(self)

    async def setup_hook(self):
        guild_id = os.getenv('DISCORD_GUILD_ID')
        if guild_id:
            guild = discord.Object(id=int(guild_id))
            self.tree.copy_global_to(guild=guild)
            await self.tree.sync(guild=guild)
        else:
            await self.tree.sync()

client = Client()
gear = app_commands.Group(name='gear', description='Save and share backpacking loadouts', guild_only=True)
client.tree.add_command(gear)
# Only the latest wizard for each user/server can save. Old buttons expire.
sessions = {}

class Wizard(discord.ui.View):
    def __init__(self, interaction):
        super().__init__(timeout=600)
        self.key = (interaction.guild_id, interaction.user.id)
        self.values = store.get(*self.key) or {}
        self.index = 0
        self.next_question.label = 'Start questionnaire'
        self.shelter_chosen = False
        self.phase = 'gear'
        self.remove_item(self.tent)
        self.remove_item(self.hammock)
        self.remove_item(self.yes)
        self.remove_item(self.no)

    def current_field(self):
        if self.phase == 'underquilt_model':
            return 'Underquilt'
        if self.index == 3:
            return self.values.get('Shelter Type', 'Tent')
        return FIELDS[self.index]

    async def choose_shelter(self, interaction, kind):
        if self.index != 3 or self.shelter_chosen:
            await interaction.response.send_message('That choice was already answered.', ephemeral=True)
            return
        self.values['Shelter Type'] = kind
        if kind == 'Tent':
            self.values.pop('Underquilt', None)
            self.values.pop('Has Underquilt', None)
        self.shelter_chosen = True
        self.remove_item(self.tent)
        self.remove_item(self.hammock)
        self.next_question.disabled = False
        await interaction.response.edit_message(
            content=f'What {kind.lower()} do you use? Click Next question to enter it.',
            view=self,
        )

    @discord.ui.button(label='Tent', style=discord.ButtonStyle.primary)
    async def tent(self, interaction, button):
        await self.choose_shelter(interaction, 'Tent')

    @discord.ui.button(label='Hammock', style=discord.ButtonStyle.primary)
    async def hammock(self, interaction, button):
        await self.choose_shelter(interaction, 'Hammock')

    async def choose_underquilt(self, interaction, has_underquilt):
        if self.phase != 'underquilt_choice':
            await interaction.response.send_message('That choice was already answered.', ephemeral=True)
            return
        self.values['Has Underquilt'] = has_underquilt
        self.remove_item(self.yes)
        self.remove_item(self.no)
        self.next_question.disabled = False
        if has_underquilt:
            self.phase = 'underquilt_model'
            prompt = '**Underquilt**: Click Next question to enter your underquilt.'
        else:
            self.values.pop('Underquilt', None)
            self.phase = 'gear'
            self.index += 1
            prompt = f'**{self.current_field()}**: Click Next question to answer.'
        await interaction.response.edit_message(content=prompt, view=self)

    @discord.ui.button(label='Yes', style=discord.ButtonStyle.primary)
    async def yes(self, interaction, button):
        await self.choose_underquilt(interaction, True)

    @discord.ui.button(label='No', style=discord.ButtonStyle.secondary)
    async def no(self, interaction, button):
        await self.choose_underquilt(interaction, False)

    async def interaction_check(self, interaction):
        if (interaction.guild_id, interaction.user.id) != self.key or sessions.get(self.key) is not self:
            await interaction.response.send_message('This questionnaire expired. Start again with /gear create.', ephemeral=True)
            return False
        return True

    async def on_timeout(self):
        if sessions.get(self.key) is self:
            sessions.pop(self.key, None)

    @discord.ui.button(label='Next question', style=discord.ButtonStyle.primary)
    async def next_question(self, interaction, button):
        if self.phase == 'underquilt_choice' or (self.index == 3 and not self.shelter_chosen):
            await interaction.response.send_message('Choose an option first.', ephemeral=True)
            return
        await interaction.response.send_modal(Answer(self))

    @discord.ui.button(label='Cancel', style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction, button):
        sessions.pop(self.key, None)
        self.stop()
        await interaction.response.edit_message(content='Cancelled. Your previous saved loadout is unchanged.', view=None)

class Answer(discord.ui.Modal):
    def __init__(self, wizard):
        self.wizard = wizard
        self.index = wizard.index
        field = wizard.current_field()
        self.field = field
        super().__init__(title=f'Gear: {field}', timeout=600)
        self.answer = discord.ui.TextInput(label=field, required=False,
            default=wizard.values.get(field, ''), max_length=400 if field == 'Extra or Misc Items' else 140,
            placeholder='e.g. 12 lb / 5.4 kg, or Unweighed' if field == 'Total Base Weight' else 'Enter your gear, or leave blank for None',
            style=discord.TextStyle.paragraph if field == 'Extra or Misc Items' else discord.TextStyle.short)
        self.add_item(self.answer)

    async def on_submit(self, interaction):
        w = self.wizard
        if not await w.interaction_check(interaction):
            return
        if self.index != w.index or self.field != w.current_field() or w.phase == 'underquilt_choice':
            await interaction.response.send_message('That question was already answered.', ephemeral=True)
            return
        value = clean(self.answer.value) or ('Unweighed' if self.field == 'Total Base Weight' else 'None')
        w.values[w.current_field()] = value
        if self.field in ('Tent', 'Hammock'):
            other = 'Tent' if self.field == 'Hammock' else 'Hammock'
            w.values.pop(other, None)
        if self.field == 'Hammock':
            w.phase = 'underquilt_choice'
            w.next_question.label = 'Next question'
            w.next_question.disabled = True
            w.add_item(w.yes)
            w.add_item(w.no)
            await interaction.response.edit_message(content='**Do you have a hammock underquilt?**', view=w)
            return
        if self.field == 'Underquilt':
            w.phase = 'gear'
        if self.index == len(FIELDS) - 1:
            store.save(*w.key, w.values)
            sessions.pop(w.key, None)
            w.stop()
            await interaction.response.edit_message(content='Saved! Use /gear show to post this list in the channel.\n' + render(w.values), view=None)
        else:
            w.index += 1
            w.next_question.label = 'Next question'
            if w.index == 3:
                w.next_question.disabled = True
                w.add_item(w.tent)
                w.add_item(w.hammock)
                await interaction.response.edit_message(
                    content='**Tent or Hammock?** Choose your shelter below.', view=w,
                )
                return
            await interaction.response.edit_message(content=f'Question {w.index + 1}/{len(FIELDS)}: **{FIELDS[w.index]}**\nClick Next question to answer. Unsaved questionnaires expire after 10 minutes of inactivity.', view=w)

    async def on_error(self, interaction, error):
        log.error('Questionnaire failed', exc_info=(type(error), error, error.__traceback__))
        if not interaction.response.is_done():
            await interaction.response.send_message('Could not save your answer. Try again; your previous saved loadout is unchanged.', ephemeral=True)

@gear.command(name='create', description='Create or replace your loadout, one question at a time')
async def create(interaction: discord.Interaction):
    wizard = Wizard(interaction)
    previous = sessions.get(wizard.key)
    if previous:
        previous.stop()
    sessions[wizard.key] = wizard
    await interaction.response.send_message('Create your backpacking loadout.\nYour completed list can be requested by anyone in this server. Existing answers are prefilled when editing.\nStart with **Backpack**.', view=wizard, ephemeral=True)

@gear.command(name='show', description='Post your loadout or another member’s loadout')
@app_commands.describe(member='Leave empty for your own loadout')
async def show(interaction: discord.Interaction, member: discord.Member | None = None):
    target = member or interaction.user
    values = store.get(interaction.guild_id, target.id)
    if values is None:
        await interaction.response.send_message('No saved loadout for that member in this server. Use /gear create to make your own.', ephemeral=True)
        return
    name = discord.utils.escape_markdown(clean(target.display_name))
    await interaction.response.send_message(f'**{name} — backpacking gear**\n' + render(values), allowed_mentions=discord.AllowedMentions.none())

@gear.command(name='delete', description='Delete your saved loadout')
async def delete(interaction: discord.Interaction):
    key = (interaction.guild_id, interaction.user.id)
    wizard = sessions.pop(key, None)
    if wizard:
        wizard.stop()
    removed = store.delete(*key)
    await interaction.response.send_message('Your saved loadout was deleted.' if removed else 'You have no saved loadout.', ephemeral=True)

@client.tree.error
async def command_error(interaction, error):
    log.error('Command failed', exc_info=(type(error), error, error.__traceback__))
    message = 'The command failed. Check the bot logs and try again.'
    if interaction.response.is_done():
        await interaction.followup.send(message, ephemeral=True)
    else:
        await interaction.response.send_message(message, ephemeral=True)

if __name__ == '__main__':
    token = os.getenv('DISCORD_TOKEN')
    if not token:
        raise SystemExit('Set DISCORD_TOKEN in .env first. See README.md.')
    client.run(token)
