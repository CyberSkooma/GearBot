import logging
import os
from pathlib import Path

import discord
from discord import app_commands
from dotenv import load_dotenv
from gear import FIELDS, Store, clean, render

load_dotenv(Path(__file__).with_name('.env'))
log = logging.getLogger('backpacking')
store = Store(os.getenv('GEAR_DATABASE', str(Path(__file__).with_name('gear.sqlite3'))))

class Client(discord.Client):
    def __init__(self):
        super().__init__(intents=discord.Intents.none(), allowed_mentions=discord.AllowedMentions.none())
        self.tree = app_commands.CommandTree(self)

    async def setup_hook(self):
        guild_id = os.getenv('DISCORD_GUILD_ID')
        if guild_id:
            guild = discord.Object(id=int(guild_id))
            self.tree.copy_global_to(guild=guild)
            await self.tree.sync(guild=guild)
        else:
            await self.tree.sync()

client = Client()
gear = app_commands.Group(name='gear', description='Save and share backpacking loadouts', guild_only=True)
client.tree.add_command(gear)
# Only the latest wizard for each user/server can save. Old buttons expire.
sessions = {}

class Wizard(discord.ui.View):
    def __init__(self, interaction):
        super().__init__(timeout=600)
        self.key = (interaction.guild_id, interaction.user.id)
        self.values = store.get(*self.key) or {}
        self.index = 0
        self.next_question.label = 'Start questionnaire'

    async def interaction_check(self, interaction):
        if (interaction.guild_id, interaction.user.id) != self.key or sessions.get(self.key) is not self:
            await interaction.response.send_message('This questionnaire expired. Start again with /gear create.', ephemeral=True)
            return False
        return True

    async def on_timeout(self):
        if sessions.get(self.key) is self:
            sessions.pop(self.key, None)

    @discord.ui.button(label='Next question', style=discord.ButtonStyle.primary)
    async def next_question(self, interaction, button):
        await interaction.response.send_modal(Answer(self))

    @discord.ui.button(label='Cancel', style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction, button):
        sessions.pop(self.key, None)
        self.stop()
        await interaction.response.edit_message(content='Cancelled. Your previous saved loadout is unchanged.', view=None)

class Answer(discord.ui.Modal):
    def __init__(self, wizard):
        self.wizard = wizard
        self.index = wizard.index
        field = FIELDS[self.index]
        super().__init__(title=f'Gear: question {self.index + 1} of {len(FIELDS)}', timeout=600)
        self.answer = discord.ui.TextInput(label=field, required=False,
            default=wizard.values.get(field, ''), max_length=400 if self.index == 7 else 140,
            placeholder='e.g. 12 lb / 5.4 kg, or Unweighed' if self.index == 8 else 'Enter your gear, or leave blank for None',
            style=discord.TextStyle.paragraph if self.index == 7 else discord.TextStyle.short)
        self.add_item(self.answer)

    async def on_submit(self, interaction):
        w = self.wizard
        if not await w.interaction_check(interaction):
            return
        if self.index != w.index:
            await interaction.response.send_message('That question was already answered.', ephemeral=True)
            return
        value = clean(self.answer.value) or ('Unweighed' if self.index == 8 else 'None')
        w.values[FIELDS[self.index]] = value
        if self.index == len(FIELDS) - 1:
            store.save(*w.key, w.values)
            sessions.pop(w.key, None)
            w.stop()
            await interaction.response.edit_message(content='Saved! Use /gear show to post this list in the channel.\n' + render(w.values), view=None)
        else:
            w.index += 1
            w.next_question.label = 'Next question'
            await interaction.response.edit_message(content=f'Question {w.index + 1}/{len(FIELDS)}: **{FIELDS[w.index]}**\nClick Next question to answer. Unsaved questionnaires expire after 10 minutes of inactivity.', view=w)

    async def on_error(self, interaction, error):
        log.error('Questionnaire failed', exc_info=(type(error), error, error.__traceback__))
        if not interaction.response.is_done():
            await interaction.response.send_message('Could not save your answer. Try again; your previous saved loadout is unchanged.', ephemeral=True)

@gear.command(name='create', description='Create or replace your loadout, one question at a time')
async def create(interaction: discord.Interaction):
    wizard = Wizard(interaction)
    previous = sessions.get(wizard.key)
    if previous:
        previous.stop()
    sessions[wizard.key] = wizard
    await interaction.response.send_message('Create your backpacking loadout.\nYour completed list can be requested by anyone in this server. Existing answers are prefilled when editing.\nStart with **Backpack**.', view=wizard, ephemeral=True)

@gear.command(name='show', description='Post your loadout or another member’s loadout')
@app_commands.describe(member='Leave empty for your own loadout')
async def show(interaction: discord.Interaction, member: discord.Member | None = None):
    target = member or interaction.user
    values = store.get(interaction.guild_id, target.id)
    if values is None:
        await interaction.response.send_message('No saved loadout for that member in this server. Use /gear create to make your own.', ephemeral=True)
        return
    name = discord.utils.escape_markdown(clean(target.display_name))
    await interaction.response.send_message(f'**{name} — backpacking gear**\n' + render(values), allowed_mentions=discord.AllowedMentions.none())

@gear.command(name='delete', description='Delete your saved loadout')
async def delete(interaction: discord.Interaction):
    key = (interaction.guild_id, interaction.user.id)
    wizard = sessions.pop(key, None)
    if wizard:
        wizard.stop()
    removed = store.delete(*key)
    await interaction.response.send_message('Your saved loadout was deleted.' if removed else 'You have no saved loadout.', ephemeral=True)

@client.tree.error
async def command_error(interaction, error):
    log.error('Command failed', exc_info=(type(error), error, error.__traceback__))
    message = 'The command failed. Check the bot logs and try again.'
    if interaction.response.is_done():
        await interaction.followup.send(message, ephemeral=True)
    else:
        await interaction.response.send_message(message, ephemeral=True)

if __name__ == '__main__':
    token = os.getenv('DISCORD_TOKEN')
    if not token:
        raise SystemExit('Set DISCORD_TOKEN in .env first. See README.md.')
    client.run(token)
