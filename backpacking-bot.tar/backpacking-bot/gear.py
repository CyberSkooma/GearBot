import json
import sqlite3

FIELDS = ["Backpack", "Sleeping Bag", "Sleeping Pad", "Tent", "Cook Stove",
          "Cook Pot", "Water filtration", "Extra or Misc Items", "Total Base Weight"]

def clean(value):
    return " ".join(value.replace("`", "'").split())

def render(values):
    lines = []
    for i, field in enumerate(FIELDS):
        if i == 7:
            lines.append("")
        lines.append(f"{field}: {clean(values.get(field, 'Unweighed' if i == 8 else 'None'))}")
    return "```\n" + "\n".join(lines) + "\n```"

class Store:
    def __init__(self, path):
        self.path = path
        with self.connect() as db:
            db.execute('CREATE TABLE IF NOT EXISTS gear (guild INTEGER, user INTEGER, data TEXT NOT NULL, PRIMARY KEY(guild,user))')

    def connect(self):
        return sqlite3.connect(self.path, timeout=10)

    def get(self, guild, user):
        with self.connect() as db:
            row = db.execute('SELECT data FROM gear WHERE guild=? AND user=?', (guild, user)).fetchone()
        return json.loads(row[0]) if row else None

    def save(self, guild, user, values):
        with self.connect() as db:
            db.execute('INSERT INTO gear VALUES (?,?,?) ON CONFLICT(guild,user) DO UPDATE SET data=excluded.data',
                       (guild, user, json.dumps(values)))

    def delete(self, guild, user):
        with self.connect() as db:
            return db.execute('DELETE FROM gear WHERE guild=? AND user=?', (guild, user)).rowcount > 0
